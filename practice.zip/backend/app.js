const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

// const Post = require("./models/post");
const User = require("./models/user");

const app = express();

mongoose
  .connect(
    "mongodb://localhost:27017/assignment", { useNewUrlParser: true }
  )
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, DELETE, OPTIONS"
  );
  next();
});

// app.post("/api/posts", (req, res, next) => {
//   const post = new Post({
//     title: req.body.title,
//     content: req.body.content
//   });
//   post.save().then(createdPost => {
//     res.status(201).json({
//       message: "Post added successfully",
//       postId: createdPost._id
//     });
//   });
// });

app.post("/api/users", (req, res, next) => {
  const user = new User({
    email: req.body.email,
    password: req.body.password,
    fName: req.body.fName,
    lName: req.body.lName,
    created_on: new Date()
  });
  user.save().then(createdUser => {
    res.status(201).json({
      message: "User added successfully",
      userId: createdUser._id
    });
  });
});

app.get("/api/users", (req, res, next) => {
  User.find().then(users => {
    res.status(200).json({
      message: "Users fetched successfully!",
      users: users
    });
  });
});

app.get("/api/users/:id", (req, res, next) => {
  console.log(req.params.id);
  User.findOne({ _id: req.params.id}).then(user => {
    console.log(user);
    res.status(200).json({
      message: "Users fetched successfully!",
      user: user
    });
  });
});

app.post("/api/users/:id", (req, res, next) => {
  console.log('request parameters', req.params);
  const user = new User({
    email: req.body.email,
    password: req.body.password,
    fName: req.body.fName,
    lName: req.body.lName,
    created_on: req.body.created_on,
    updated_on: new Date()
  });
  user.save().then(updateddUser => {
    res.status(201).json({
      message: "User added successfully",
      userId: updateddUser._id
    });
  });
});


app.delete("/api/users/:id", (req, res, next) => {
  User.deleteOne({ _id: req.params.id }).then(result => {
    console.log(result);
    res.status(200).json({ message: "User deleted!" });
  });
});

// app.get("/api/posts", (req, res, next) => {
//   Post.find().then(documents => {
//     res.status(200).json({
//       message: "Posts fetched successfully!",
//       posts: documents
//     });
//   });
// });

// app.delete("/api/posts/:id", (req, res, next) => {
//   Post.deleteOne({ _id: req.params.id }).then(result => {
//     console.log(result);
//     res.status(200).json({ message: "Post deleted!" });
//   });
// });

module.exports = app;
