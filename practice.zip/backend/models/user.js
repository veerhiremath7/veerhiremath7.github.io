const mongoose = require('mongoose');
var Schema = mongoose.Schema;

const userSchema = Schema({
  email: { type: String, required: true },
  password: { type: String, required: true },
  fName: { type: String, required: true },
  lName: { type: String, required: true },
  created_on: { type: Date, required: true},
  updated_on: { type: Date }
});

module.exports = mongoose.model('Usss', userSchema);
