import { Component, OnInit } from '@angular/core';
import { UsersService } from './users.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users: any[] = [];
  private usersSub: Subscription;
  // nameFilter = '';
  // nameFilter:lastNameFilter:emailFilter:createdDateFilter:updatedDateFilter
  // later use for filters

  constructor(private userService: UsersService) { }

  ngOnInit() {
    this.userService.getUsers();
    this.usersSub = this.userService.getPostUpdateListener()
      .subscribe((users) => {
        this.users = users;
        console.log(users);
        this.users.sort( (a, b) =>  a.fName > b.fName || a.lName > b.lName ? 1 : -1 );
      });
  }

  // onEdit(id) {
  //   this.ro
  // }

  onDelete(userId: string) {
    this.userService.deletePost(userId);
  }

}
