import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from '../users.service';
import { Subscription } from 'rxjs';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
  id: string;
  user: any = {};
  loading = false;
  submitted = false;

  constructor(
    private route: ActivatedRoute,
    private usersService: UsersService,
    private router: Router,
    private formBuilder: FormBuilder
    ) { }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    this.usersService.editUser(this.id).subscribe( (data) => {
      this.user = data.user;
    });
  }

  onSubmit() {
        this.usersService.updateUser(
          this.user._id, this.user.email,
          this.user.password,
          this.user.fName,
          this.user.lName,
          this.user.created_on);
        this.router.navigate(['/']);
    }

}
