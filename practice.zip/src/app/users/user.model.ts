export interface User {
  id: string;
  fName: string;
  lName: string;
  email: string;
  password: string;
}
