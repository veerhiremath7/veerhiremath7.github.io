import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'userFilter'})

export class UserFilterPipe implements PipeTransform {

    transform(value: any[], emailFilter: string, nameFilter: string, lastNameFilter: string, dateFilter: string): any[] {
        if (value && value.length) {
            return value.filter(user => {
                if (emailFilter && user.email.toLowerCase().indexOf(emailFilter.toLocaleLowerCase()) === -1) {
                    return false;
                }

                if (nameFilter && user.fName.toLowerCase().indexOf(nameFilter.toLocaleLowerCase()) === -1) {
                    return false;
                }

                if (lastNameFilter && user.lName.toLowerCase().indexOf(lastNameFilter.toLocaleLowerCase()) === -1) {
                    return false;
                }

                if (dateFilter && user.created_on.toLowerCase().indexOf(dateFilter.toLocaleLowerCase()) === -1) {
                    return false;
                }

                return true;
            });
        } else {
            return value;
        }
    }
}
