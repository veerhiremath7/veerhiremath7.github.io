import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
// import { User } from './user.model';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class UsersService {
    getUser;
    private user: any[] = [];

    private users: any[] = [];
    private usersUpdated = new Subject<any[]>();
    private userUpdated = new Subject<any[]>();

    private httpOption = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    };

    constructor(private http: HttpClient, private router: Router) {}

    getUsers() {
    this.http
      .get<{ message: string; users: any }>(
        'http://localhost:3000/api/users'
      )
      .pipe(map((postData) => {
          this.getUser = JSON.parse(localStorage.getItem('isLoggedIn'));
        return postData.users.map(user => {
          return {
            email: user.email,
            fName: user.fName,
            lName: user.lName,
            created_on: user.created_on,
            updated_on: user.updated_on,
            id: user._id
          };
        });
      }))
      .subscribe(transformedPosts => {
        this.users = transformedPosts;
        this.usersUpdated.next([...this.users]);
      });
  }

  login(email, password) {
      this.http.get<{message: string, users: any}>(
          'http://localhost:3000/api/users'
          ).pipe(map((postData) => {
        return postData.users.map(user => {
            if (email === user.email && password === user.password) {
                console.log('login success');
                localStorage.setItem('isLoggedIn', 'true');
                this.getUser = 'true';
                this.router.navigate(['/']);
            } else {
                console.log('login failed');
            }
        });
      }));
  }
  getPostUpdateListener() {
      return this.usersUpdated.asObservable();
  }

  editUser(id: string) {
      return this.http.get<{message: string, user: any}>('http://localhost:3000/api/users/' + id);
    //     .pipe(map((pData) => {
    //       console.log('this is pData', pData);
    //         return pData.user;
    //   }));
  }

  addUser(email: string, password: string, fName: string, lName: string) {
    const user = { id: null, email: email, password: password, fName: fName, lName: lName};
    this.http
      .post<{ message: string, userId: string }>('http://localhost:3000/api/users', user)
      .subscribe(responseData => {
        const id = responseData.userId;
        user.id = id;
        this.users.push(user);
        this.usersUpdated.next([...this.users]);
      });
  }

  updateUser(id, username, password, firstName, lastName, created_on) {
    const user = { id: id, email: username, password: password, fName: firstName, lName: lastName, created_on: created_on};
    console.log(user);
    this.http.post<{message: string, userId: string}>('http://localhost:3000/api/users/' + id, user)
    .subscribe( response => {
        console.log('response', response);
        this.users.push(user);
        this.usersUpdated.next([...this.users]);
    });
  }

  deletePost(userId: string) {
      console.log(userId);
    this.http.delete('http://localhost:3000/api/users/' + userId)
      .subscribe(() => {
        const updatedUsers = this.users.filter(user => user.id !== userId);
        this.users = updatedUsers;
        this.usersUpdated.next([...this.users]);
      });
  }



}
