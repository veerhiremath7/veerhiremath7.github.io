import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UsersService } from '../users/users.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UsersService
  ) {
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', [
              Validators.required,
              // Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[A-Za-z\d$@$!%*?&].{8,20}')
              ]]
        });
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
        this.submitted = true;

        if (this.loginForm.invalid) {
            return;
        }

        this.userService.login(this.loginForm.value.email, this.loginForm.value.password);
        localStorage.setItem('isLoggedIn', 'true');
        this.router.navigate(['/']);
    }

}
